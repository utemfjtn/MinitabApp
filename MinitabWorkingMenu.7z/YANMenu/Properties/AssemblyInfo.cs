using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: ComVisible(true)]
[assembly: AssemblyTrademark("")]
[assembly: Guid("fa82bbfc-1150-4706-885d-a62da4179f90")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.Default | DebuggableAttribute.DebuggingModes.DisableOptimizations)]
[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: AssemblyTitle("YANMenu")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("YANMenu")]
[assembly: AssemblyCopyright("© 2019 Minitab, LLC All rights reserved.")]
[assembly: AssemblyVersion("1.0.0.0")]
